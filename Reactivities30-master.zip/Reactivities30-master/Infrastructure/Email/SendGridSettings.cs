namespace Infrastructure.Email
{
    public class SendGridSettings
    {
        public string User { get; set; }
        public string Key { get; set; }
    }
}